// ================= PIN =================
#define LDR1 34
#define LDR2 35
#define LDR3 32
#define LDR4 33

#define STEP_X 18
#define DIR_X 19

#define STEP_Y 21
#define DIR_Y 22

// ================= PARAMETER =================
int deadzone = 100;
int maxRange = 2000;

float alpha = 0.7;
float smoothX = 0;
float smoothY = 0;

// ================= STRUCT FUZZY =================
struct FuzzySet {
  float neg;
  float zero;
  float pos;
};

struct FuzzyOutput {
  float lambat;
  float sedang;
  float cepat;
};

// ================= SETUP =================
void setup() {
  Serial.begin(115200);

  pinMode(STEP_X, OUTPUT);
  pinMode(DIR_X, OUTPUT);
  pinMode(STEP_Y, OUTPUT);
  pinMode(DIR_Y, OUTPUT);
}

// ================= STEP =================
void stepSmooth(int stepPin, int dirPin, bool dir, int speedDelay) {
  digitalWrite(dirPin, dir);
  digitalWrite(stepPin, HIGH);
  delayMicroseconds(speedDelay);
  digitalWrite(stepPin, LOW);
  delayMicroseconds(speedDelay);
}

// =======================================================
// 1. FUZZIFIKASI
// =======================================================
FuzzySet fuzzifikasi(int x) {
  FuzzySet f;

  // NEGATIVE
  if (x <= -maxRange) f.neg = 1;
  else if (x >= 0) f.neg = 0;
  else f.neg = (-x) / (float)maxRange;

  // POSITIVE
  if (x >= maxRange) f.pos = 1;
  else if (x <= 0) f.pos = 0;
  else f.pos = x / (float)maxRange;

  // ZERO
  if (abs(x) >= maxRange) f.zero = 0;
  else f.zero = 1 - (abs(x) / (float)maxRange);

  return f;
}

// =======================================================
// 2. RULE BASE (MAMDANI)
// =======================================================
FuzzyOutput ruleEvaluation(FuzzySet f) {
  FuzzyOutput out;

  // Rule:
  // IF error besar → cepat
  out.cepat = max(f.neg, f.pos);

  // IF error kecil → lambat
  out.lambat = f.zero;

  // sisanya → sedang
  out.sedang = 1 - max(out.lambat, out.cepat);

  return out;
}

// =======================================================
// 3. DEFUZZIFIKASI (COG)
// =======================================================
int defuzzifikasi(FuzzyOutput out) {

  float z_lambat = 2500;
  float z_sedang = 1400;
  float z_cepat  = 600;

  float atas =
    out.lambat * z_lambat +
    out.sedang * z_sedang +
    out.cepat  * z_cepat;

  float bawah =
    out.lambat + out.sedang + out.cepat;

  if (bawah == 0) return 2500;

  return atas / bawah;
}

// =======================================================
// 4. PIPELINE FUZZY  
// =======================================================
int fuzzyMamdani(int error) {

  // 1. Fuzzifikasi
  FuzzySet f = fuzzifikasi(error);

  // 2. Rule
  FuzzyOutput out = ruleEvaluation(f);

  // 3. Defuzzifikasi
  return defuzzifikasi(out);
}

// ================= LOOP =================
void loop() {

  // ===== SENSOR =====
  int ldr1 = analogRead(LDR1);
  int ldr2 = analogRead(LDR2);
  int ldr3 = analogRead(LDR3);
  int ldr4 = analogRead(LDR4);

  int kiri  = ldr1 + ldr3;
  int kanan = ldr2 + ldr4;

  int atas  = ldr1 + ldr2;
  int bawah = ldr3 + ldr4;

  int errorX = kiri - kanan;
  int errorY = atas - bawah;

  // ===== SMOOTHING =====
  smoothX = alpha * errorX + (1 - alpha) * smoothX;
  smoothY = alpha * errorY + (1 - alpha) * smoothY;

  // ===== FUZZY =====
  int speedX = fuzzyMamdani(smoothX);
  int speedY = fuzzyMamdani(smoothY);

  // ===== ARAH =====
  String arahX = "CENTER";
  String arahY = "CENTER";
  String status = "STABLE";

  if (smoothX > deadzone) arahX = "LEFT";
  else if (smoothX < -deadzone) arahX = "RIGHT";

  if (smoothY > deadzone) arahY = "UP";
  else if (smoothY < -deadzone) arahY = "DOWN";

  // ===== GERAK =====
  if (abs(smoothX) > abs(smoothY)) {

    if (abs(smoothX) > deadzone) {
      digitalWrite(DIR_X, smoothX < 0);
      stepSmooth(STEP_X, DIR_X, smoothX < 0, speedX);
      status = "TRACK X";
    }

  } else {

    if (abs(smoothY) > deadzone) {
      digitalWrite(DIR_Y, smoothY < 0);
      stepSmooth(STEP_Y, DIR_Y, smoothY < 0, speedY);
      status = "TRACK Y";
    }
  }

  // ===== OUTPUT =====
  Serial.print("X: "); Serial.print(smoothX);
  Serial.print(" | Y: "); Serial.print(smoothY);
  Serial.print(" | AX: "); Serial.print(arahX);
  Serial.print(" | AY: "); Serial.print(arahY);
  Serial.print(" | SX: "); Serial.print(speedX);
  Serial.print(" | SY: "); Serial.print(speedY);
  Serial.print(" | "); Serial.println(status);

  delay(50);
}